# Load the rails application
require File.expand_path('../application', __FILE__)
require 'rspec/expectations'
# Initialize the rails application
Rottenpotatoes::Application.initialize!
